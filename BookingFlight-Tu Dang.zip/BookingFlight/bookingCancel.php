<?php
	sleep(1);
		$username = $_GET["b"];
		echo "<h2 style='position: absolute; top:2em; right: 3em;'>";
		echo $username;
		echo "</h2>";
		
		include "config.php";
		$sql = "SELECT * from user_account WHERE username = '".$username."'";
		$result = $conn->query($sql);
	
		if($result->num_rows > 0) {
		if($row = mysqli_fetch_array($result)) {
				echo "<p style='position: absolute; top:5em; right: 5em;'>";
				echo "(Logged in)";
				echo "</p>";
		}}
	
?>
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Flight</title>
<link rel="stylesheet" href = "./bookingFlight.css">
<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="bookingFlight.js"></script>
</head>

<body>
<div class="booking-box">
<div id="information" style="text-align:center; margin: 0">
		<h2>Hi, 
		<?php

							$host ='';		
							$sql = "SELECT * FROM user_account WHERE username ='".$username."'";
							$result = $conn->query($sql);

							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["FirstName"];
									echo " ";
									echo $row["LastName"];
									echo "!";
									$host = $row["LastName"];
								}
							}
				
		?>
		</h2>

			
			<?php
			
			
			$sql = "SELECT * FROM bookings WHERE username ='".$username."'";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				echo '<table style="text-align:center; margin: auto">
				<tr>
				<th>Last Name</th>
				<th>Ticket No.</th>
				<th>Departure City</th>
				<th>Destination</th> 
				<th>Departure Date</th>
				<th>Request</th>
				</tr>';
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>";
					echo $host;
					echo "</td><td>";
					echo $row['ID'];
					echo "</td><td>";
					echo $row["departure_city"];
					echo "</td><td>";
					echo $row["destination"];
					echo "</td><td>";
					echo $row["departure_date"];
					echo "</td><td>";
					echo "<a style='text-decoration: none;' onclick='confirmCancel()' href='cancel.php?a=".$row['ID']. "&b=". $row['username']."'>Cancel</a>";
					echo "</td></tr>";
				}
				echo "</table>";
			} else {
				echo "You have not booked any trip.";
			}
			?>
			 
			
		
	
	<p id="messageBook"><a href="#" style="text-decoration: none; box-shadow: 2px 2px grey; border-radius: 3px; background-color:#f2f2f2; padding: 4px;">Book more flights</a></p>
	
	<p><a href="loginBooking.php" style="text-decoration: none; box-shadow: 2px 2px grey; border-radius: 3px; background-color:#f2f2f2; padding: 4px;">Log out</a></p>
	
</div>



<form id="booked" style="text-align:center; margin: 0" action="bookingFlight3.php" method="POST">
	
	<input type="hidden" name="userLogin2" value="<?php echo $username; ?>">
	Departure from 	<br>
	<div id="departure_city2"><input id="departure_city" type="text" name="departure_city" class="form-control" placeholder="City" required></div>
	
	Flying to <br>
	<div id="destination2"><input id="destination" type="text" name="destination" class="form-control" placeholder="City" required></div>
	

	Departure Date<br>
	<input type="date" id="departure_date" name="departure_date" class="form-control select-date" required><br>

	
	<input type="submit" id="booking-button" value="Book &#9992">
	
	<p id="messageInfor"><a href="#" style="text-decoration: none; box-shadow: 2px 2px grey; border-radius: 3px; background-color:#f2f2f2; padding: 4px;">Check my flight</a></p>
	<p><a href="loginBooking.php" style="text-decoration: none; box-shadow: 2px 2px grey; border-radius: 3px; background-color:#f2f2f2; padding: 4px;">Log Out</a></p>
</form>

</div>
</body>
</html>