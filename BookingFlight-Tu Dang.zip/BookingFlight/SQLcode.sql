CREATE TABLE `user_account` (
 `Username` varchar(40) NOT NULL,
 `Password` varchar(40) NOT NULL,
 `FirstName` varchar(40) NOT NULL,
 `LastName` varchar(40) NOT NULL,
 `Email` varchar(40) NOT NULL,
 `BillingAddress` varchar(40) NOT NULL,
 PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `bookings` (
 `ID` int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
 `username` varchar(50) NOT NULL,
 `departure_city` varchar(50) NOT NULL,
 `destination` varchar(50) NOT NULL,
 `departure_date` date NOT NULL,
 UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4