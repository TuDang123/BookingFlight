<?php
	include "config.php";
	$nameErr1 = "";
	$usernameRegister = "";
	$passwordRegister = "";
	$firstname = "";
	$lastname = "";
	$bill_address = "";
	$email = "";
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Flight</title>
<link rel="stylesheet" href = "./bookingFlight.css">
<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="bookingFlight.js"></script>

</head>



<body>

<div class="booking-box">

<form id="register-form" style="text-align:center; margin: 0" action=" <?php echo $_SERVER["PHP_SELF"];?> " method="POST">
	
	<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$usernameRegister = $_POST["username"];
	$passwordRegister = $_POST["password1"];
	$firstname = $_POST["fname"];
	$lastname = $_POST["lname"];
	$bill_address = $_POST["baddress"];
	$email = $_POST["email"];

	$sql = "SELECT username FROM user_account WHERE username = '".$usernameRegister."'";
	$register = $conn->query($sql);
	
	//Get the result and confirm logging
	
	if($register->num_rows > 0)
	{
		$nameErr1 = "<br>* Username is already taken.";
	}else {	
		$sql2 =  "INSERT INTO user_account 
					VALUES ('".$usernameRegister."','".$passwordRegister."','".$firstname."', '".$lastname."','".$email."','".$bill_address."')";
	
		if ($conn->query($sql2) == TRUE) {
		
			$sender = "troycstester@gmail.com";
            $subject="Booking Flight";
            $receiver=$_POST["lname"];
            $receiverEmail=$_POST["email"];

             $mailBody="Dear $firstname $receiver, \nThank you for your registration. You can book your flight now.\n Sincerely, \n Tu Dang";

              mail($receiverEmail, $subject, $mailBody, "From: Tu Dang <$sender>");
              
				
				//header("Location: loginBooking.php");	
				echo "<script type=\"text/javascript\">window.alert('Registered Success. Please check your email and log in.');window.location= 'loginBooking.php';</script>"; 
		} 
	}
	}
?>		  
	User name: <input  type="text" name="username" placeholder="Enter your user name" value="<?php echo $usernameRegister;?>" required> 
	<span style="color: red;"><?php echo $nameErr1; ?></span><br>
	
    Password: <input  type="password" id="password1" name="password1" placeholder="Enter your password" value="<?php echo $passwordRegister;?>" required><br>
	
	Confirm Password:<input type="password" id="password2" onchange="checkPasswordMatch()" name="password2" placeholder="Retype your password" value="<?php echo $passwordRegister;?>" required>
	<p style="display:inline" id="demo"></p> <br>
	First name: <input type="text" name="fname" placeholder="Enter your first name" value="<?php echo $firstname;?>" required><br>
    Last name: <input type="text" name="lname" placeholder="Enter your last name" value="<?php echo $lastname;?>" required><br>
	Billing address: <input type="text" name="baddress" placeholder="Enter your billing address" value="<?php echo $bill_address;?>" required><br>
    Email:  <input type="email" name="email" placeholder="Enter your email" value="<?php echo $email;?>" required> 
	
	<br>
	<input id="button2" type="submit" name="register" style="vertical-align:middle" value="Register">


	
	<br>
	<p id="messageLogin">Already have account? <a href="loginBooking.php" style="text-decoration: none; box-shadow: 2px 2px grey; border-radius: 3px; background-color:#f2f2f2; padding: 4px;"x>Login</a></p>
</form> 

</div>

</body>

</html>