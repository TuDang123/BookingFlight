<?php 
			include "config.php";
			$ID=$_GET["a"];
			$username = $_GET["b"];
			echo $ID;
			echo "<br>".$username;
			//Get the result and confirm logging
			
			$sql2 ="DELETE FROM bookings WHERE ID ='".$ID."'";
			$conn->query($sql2);
			$url= "Location: bookingCancel.php?b=".$username;
			header($url);
			exit();
?>