<?php
	include "config.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Flight</title>
<link rel="stylesheet" href = "./bookingFlight.css">

<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="bookingFlight.js"></script>



</head>



<body>

<div class="booking-box">

<form id="login-form" style="text-align:center; margin: 0" action="bookingFlight2.php" method="POST">

	
	Please log in to book a flight. <br><br>
	
	User name: <input  type="text" id="usernameLogin" name="usernameLogin" placeholder="Enter your user name" required><br>
    Password: <input  type="password" id="passwordLogin" name="passwordLogin" placeholder="Enter your password name" required><br>
	
	
	
    <input type="submit" id="getusers" name="getusers" style="vertical-align:middle" value="Login">

	<p id="messageRegister">Not registered? <a href="registerFlight.php" style="text-decoration: none; box-shadow: 2px 2px grey; border-radius: 3px; background-color:#f2f2f2; padding: 4px;">Register</a> </p>
	
</form>
</div>

</body>

</html>